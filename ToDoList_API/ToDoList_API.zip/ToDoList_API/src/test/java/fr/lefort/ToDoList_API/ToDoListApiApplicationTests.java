package fr.lefort.ToDoList_API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToDoListApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
